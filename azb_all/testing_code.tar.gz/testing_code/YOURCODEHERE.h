#include <iostream>
#include <sstream>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <sys/stat.h>
#include <unistd.h>
#include <algorithm>
#include <fstream>
#include <map>
#include <math.h>
#include <fcntl.h>
#include <vector>
#include <iterator>
#include <string>

using namespace std;

std::string generateCacheLatencyParams(string halfBackedConfig);
int validateConfiguration(std::string configuration);

package Project.common;

public abstract class Constants {
    public static final long DEFAULT_CLIENT_ID = -1L;
}
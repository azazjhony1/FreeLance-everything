package Project.server;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.logging.Level;
import java.util.logging.Logger;

import Project.common.Constants;
import Project.common.Payload;


public class Room implements AutoCloseable {
	
	private String name;
	private List<ServerThread> clients = Collections.synchronizedList(new ArrayList<ServerThread>());
	private boolean isRunning = false;
	// Commands
	private final static String COMMAND_TRIGGER = "/";
	private final static String CREATE_ROOM = "createroom";
	private final static String JOIN_ROOM = "joinroom";
	private final static String DISCONNECT = "disconnect";
	private final static String LOGOUT = "logout";
	private final static String LOGOFF = "logoff";
	private static Logger logger = Logger.getLogger(Room.class.getName());
	// hangman commands, all used below will explain 
	private final static String empty = "";
	private static int lives = 7;
	private static String[] hangmanList = { "water", "keyboard", "mouse", "chair", "table", "keeper" }; //list of random words
	private static String random = "";
	private static String blanks = "";
	private static String[] blanksArray = null;
	int target = 0;

	public Room(String name) {
		this.name = name;
		isRunning = true;
	}

	private void info(String message) {
		logger.log(Level.INFO, String.format("Room[%s]: %s", name, message));
	}

	public String getName() {
		return name;
	}

	public boolean isRunning() {
		return isRunning;
	}

	protected synchronized void addClient(ServerThread client) {
		if (!isRunning) {
			return;
		}
		client.setCurrentRoom(this);
		if (clients.indexOf(client) > -1) {
			info("Attempting to add a client that already exists");
		} else {
			clients.add(client);
			sendConnectionStatus(client, true);
			sendRoomJoined(client);
			sendUserListToClient(client);
		}
	}

	protected synchronized void removeClient(ServerThread client) {
		if (!isRunning) {
			return;
		}
		clients.remove(client);
		// we don't need to broadcast it to the server
		// only to our own Room
		if (clients.size() > 0) {
			// sendMessage(client, "left the room");
			sendConnectionStatus(client, false);
		}
		checkClients();
	}

	/***
	 * Checks the number of clients.
	 * If zero, begins the cleanup process to dispose of the room
	 */
	private void checkClients() {
		// Cleanup if room is empty and not lobby
		if (!name.equalsIgnoreCase("lobby") && clients.size() == 0) {
			close();
		}
	}

	/***
	 * Helper function to process messages to trigger different functionality.
	 * 
	 * @param message The original message being sent
	 * @param client  The sender of the message (since they'll be the ones
	 *                triggering the actions)
	 */

	private void repeatLogic(String random, String[] hangmanList, String[] blanksArray) {
		random = hangmanList[(int) (Math.random() * hangmanList.length)];
		System.out.println(("Random is: " + random));
		blanks = "_".repeat(random.length());
		blanksArray = blanks.split("");
		sendMessage(null, "Next word is " + String.join(" ", blanksArray));
	}

	private boolean processCommands(String message, ServerThread client) {
//		long startTime = System.currentTimeMillis();
//		long elapsedTime = 0L;
//		while(elapsedTime<10*1000){
//			System.out.println("intime");
//			elapsedTime = (new Date()).getTime() - startTime;
//		}
//		System.out.println("time over");
		target = target%clients.size();
		if(clients.size()>0) {
			System.out.println("Turn of Player " + clients.get(target).getClientName());
		}
		boolean wasCommand = false;
		try {
			if (message.startsWith(COMMAND_TRIGGER)) {
				String[] comm = message.split(COMMAND_TRIGGER);
				String part1 = comm[1];
				String[] comm2 = part1.split(" ");
				String command = comm2[0];
				String roomName;
				wasCommand = true;
				switch (command) {
					case CREATE_ROOM:
						roomName = comm2[1];
						Room.createRoom(roomName, client);
						break;
					case JOIN_ROOM:
						roomName = comm2[1];
						Room.joinRoom(roomName, client);
						break;
					case DISCONNECT:
					case LOGOUT:
					case LOGOFF:
						Room.disconnectClient(client, this);
						break;
					default:
						wasCommand = false;
						break;
				}

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (message.startsWith("start hangman")) {
			random = hangmanList[(int) (Math.random() * hangmanList.length)];
			System.out.println("Random is: " + random);
			blanks = "_".repeat(random.length());
			blanksArray = blanks.split("");

			sendMessage(null, "Lives remaining" + lives);
			sendMessage(null, String.join(" ", blanksArray));
			sendMessage(null, "Start Guessing");
		}

		if (message.startsWith("/letter")) {
			boolean didMatch = false;
			String[] parts = message.split(" ");
			String temp = "";
			int totalPoints = client.getPoints();
			temp = parts[1].toLowerCase();
			System.out.println("Temp is: " + temp);
			int index = 0;
			boolean isExpectedPlayer = false;
			Iterator<ServerThread> iter = clients.iterator();
			while (iter.hasNext()) {
				ServerThread client1 = iter.next();


				if (index == target && client1.getClientName() == client.getClientName()) {
					isExpectedPlayer = true;
					break;
				}
				index++;


				if (random.equals(empty)) {
					return false;
				}
			}
			if (!isExpectedPlayer) {
				return false;
			}

			for (int i = 0; i < random.length(); i++) {
				if (temp.charAt(0) == random.charAt(i)) {
					blanksArray[i] = temp;
					didMatch = true;
					totalPoints++;
					client.setPoints(totalPoints);
					if (blanksArray[i] != blanks) {
						repeatLogic(random, hangmanList, blanksArray);
					}
				}
			}
			sendMessage(null, "Good job " + client.getClientName() + " You're points are: " + totalPoints);
			if (!didMatch) {
				lives--;
				sendMessage(null, "Keep trying, lives left " + lives);
				sendMessage(null, "Unlucky " + client.getClientName() + " your points are: " + client.getPoints());
			}

			while (iter.hasNext()) {
				ServerThread client1 = iter.next();
				System.out.println(client1.getClientName() + " your points are: " + client1.getPoints());

			}
			sendMessage(null, String.join(" ", blanksArray));

			// new Countdown("30 seconds left", 30,()){
			/* code when expires */
			// };
			target++;
			if (lives == 0) {
				sendMessage(null, "You have ran out of lives. Game Over, the word was " + random);
				random = empty;
				sendMessage(null, "Name: " + client.getClientName() + " Score " + client.getPoints());
			}
			if (message.startsWith("quit")) {
				sendMessage(null, "Thank you for playing");
				didMatch = false;
			}
		}

		if (message.startsWith("/word")) {
			boolean didMatch = false;
			String[] parts = message.split(" ");
			String temp = "";
			int totalPoints = client.getPoints();
			temp = parts[1];
			int counter = 0;

			if (random.equals(empty)) {
				return false;
			}

			if (temp.equalsIgnoreCase(random)) {
				didMatch = true;
				for (int i = 0; i < blanksArray.length; i++) {
					if (blanksArray[i].equals("_")) {
						counter++;
						blanksArray[i] = ""+temp.charAt(i);
					}
				}
				totalPoints = 2 * counter;
				client.setPoints(totalPoints);
				sendMessage(null, "Congratulations");
				sendMessage(null, "Good job " + client.getClientName() + " You're points are: " + totalPoints);
			}
			if (!didMatch) {
				lives--;
				sendMessage(null, "Keep trying, lives left " + lives);
				sendMessage(null, "Unlucky " + client.getClientName() + " your points are: " + client.getPoints());
			}

			target++;

			if (random.equals(empty)) {
				return false;
			}
			if (lives == 0) {
				sendMessage(null, "You have ran out of lives. Game Over, the word was " + random);
				random = empty;
				sendMessage(null, "Name: " + client.getClientName() + " Score " + client.getPoints());
			}
			if (message.startsWith("quit")) {
				didMatch = false;
			}
		
		}
		if (message.startsWith("/skip")) {
			int index = 0;
			boolean isExpectedPlayer = false;
			Iterator<ServerThread> iter = clients.iterator();
			while (iter.hasNext()) {
				ServerThread client1 = iter.next();
				if (index == target && client1.getClientName() == client.getClientName()) {
					isExpectedPlayer = true;
					System.out.println("wow");
					break;
				}
				index++;
			}
			if(!isExpectedPlayer){
				return false;
			}
			target++;
		}

		if(message.startsWith("/show")) {
			Iterator<ServerThread> iter = clients.iterator();
			while (iter.hasNext()) {
				ServerThread client1 = iter.next();
				System.out.println("Name:" + client1.getClientName() + ", Points: " + client1.getPoints());
			}
		}

		Iterator<ServerThread> iter = clients.iterator();
		while (iter.hasNext()) {
			ServerThread client1 = iter.next();
			System.out.println("Name:" + client1.getClientName() + ", Points: " + client1.getPoints());
		}

		boolean not_done = false;
		for (int i=0;i<random.length();i++){
			if(Objects.equals(blanksArray[i], "_")){
				System.out.println("done");
				not_done = true;
				break;
			}
			System.out.println(blanksArray[i]);
		}
		//ms268, hangman competed when lives run out of the word is guessed if the word is guessed next word starts otherwise game ends
		if(!not_done && random.length()>0){
			System.out.println(random);
			System.out.println("Hangman Completed");
			target = 0;
			random = hangmanList[(int) (Math.random() * hangmanList.length)];
			System.out.println(("Random is: " + random));
			blanks = "_".repeat(random.length());
			blanksArray = blanks.split("");
			sendMessage(null, "Next word is " + String.join(" ", blanksArray));
		}
		return wasCommand;

	}
	// Command helper methods

	protected static void getRooms(String query, ServerThread client) {
		String[] rooms = Server.INSTANCE.getRooms(query).toArray(new String[0]);
		client.sendRoomsList(rooms, null);
	}

	protected static void createRoom(String roomName, ServerThread client) {
		if (Server.INSTANCE.createNewRoom(roomName)) {
			Room.joinRoom(roomName, client);
		} else {
			client.sendMessage(Constants.DEFAULT_CLIENT_ID, String.format("Room %s already exists", roomName));
			client.sendRoomsList(null, String.format("Room %s already exists", roomName));
		}
	}

	protected static void joinRoom(String roomName, ServerThread client) {
		if (!Server.INSTANCE.joinRoom(roomName, client)) {
			client.sendMessage(Constants.DEFAULT_CLIENT_ID, String.format("Room %s doesn't exist", roomName));
			client.sendRoomsList(null, String.format("Room %s doesn't exist", roomName));
		}
	}

	protected static void disconnectClient(ServerThread client, Room room) {
		client.setCurrentRoom(null);
		client.disconnect();
		room.removeClient(client);
	}
	// end command helper methods

	/***
	 * Takes a sender and a message and broadcasts the message to all clients in
	 * this room. Client is mostly passed for command purposes but we can also use
	 * it to extract other client info.
	 * 
	 * @param sender  The client sending the message
	 * @param message The message to broadcast inside the room
	 */
	protected synchronized void sendMessage(ServerThread sender, String message) {
		if (!isRunning) {
			return;
		}
		info("Sending message to " + clients.size() + " clients");
		if (sender != null && processCommands(message, sender)) {
			// it was a command, don't broadcast
			return;
		}
		long from = (sender == null) ? Constants.DEFAULT_CLIENT_ID : sender.getClientId();
		synchronized (clients) {
			Iterator<ServerThread> iter = clients.iterator();
			while (iter.hasNext()) {
				ServerThread client = iter.next();
				boolean messageSent = client.sendMessage(from, message);
				if (!messageSent) {
					handleDisconnect(iter, client);
				}
			}
		}
	}

	protected synchronized void sendUserListToClient(ServerThread receiver) {
		logger.log(Level.INFO, String.format("Room[%s] Syncing client list of %s to %s", getName(), clients.size(),
				receiver.getClientName()));
		synchronized (clients) {
			Iterator<ServerThread> iter = clients.iterator();
			while (iter.hasNext()) {
				ServerThread clientInRoom = iter.next();
				if (clientInRoom.getClientId() != receiver.getClientId()) {
					boolean messageSent = receiver.sendExistingClient(clientInRoom.getClientId(),
							clientInRoom.getClientName());
					// receiver somehow disconnected mid iteration
					if (!messageSent) {
						handleDisconnect(null, receiver);
						break;
					}
				}
			}
		}
	}

	protected synchronized void sendRoomJoined(ServerThread receiver) {
		boolean messageSent = receiver.sendRoomName(getName());
		if (!messageSent) {
			handleDisconnect(null, receiver);
		}
	}

	protected synchronized void sendConnectionStatus(ServerThread sender, boolean isConnected) {
		// converted to a backwards loop to help avoid concurrent list modification
		// due to the recursive sendConnectionStatus()
		// this should only be needed in this particular method due to the recusion
		if (clients == null) {
			return;
		}
		synchronized (clients) {
			for (int i = clients.size() - 1; i >= 0; i--) {
				ServerThread client = clients.get(i);
				boolean messageSent = client.sendConnectionStatus(sender.getClientId(), sender.getClientName(),
						isConnected);
				if (!messageSent) {
					clients.remove(i);
					info("Removed client " + client.getClientName());
					checkClients();
					sendConnectionStatus(client, false);
				}
			}
		}
	}

	private synchronized void handleDisconnect(Iterator<ServerThread> iter, ServerThread client) {
		if (iter != null) {
			iter.remove();
		}
		info("Removed client " + client.getClientName());
		checkClients();
		sendConnectionStatus(client, false);
		// sendMessage(null, client.getClientName() + " disconnected");
	}

	public void close() {
		Server.INSTANCE.removeRoom(this);
		isRunning = false;
		clients = null;
	}
}